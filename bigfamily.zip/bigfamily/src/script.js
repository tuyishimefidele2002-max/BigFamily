import { initializeApp } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js";

import {
 getAuth,
 signInWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

const firebaseConfig = {
  // Paste your Firebase code here
};

const app = initializeApp(firebaseConfig);

const auth = getAuth(app);

window.login = function () {

const email =
document.getElementById("email").value;

const password =
document.getElementById("password").value;

signInWithEmailAndPassword(
auth,
email,
password
)
.then(() => {
alert("Login successful");
})
.catch((error) => {
alert(error.message);
});

}