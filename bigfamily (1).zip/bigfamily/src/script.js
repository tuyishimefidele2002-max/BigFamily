import { initializeApp } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js";

import {
 getAuth,
 createUserWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

const firebaseConfig = {
  // Your Firebase config
};

const app = initializeApp(firebaseConfig);

const auth = getAuth(app);

window.signup = function () {

const email =
document.getElementById("email").value;

const password =
document.getElementById("password").value;

createUserWithEmailAndPassword(
auth,
email,
password
)
.then(() => {
alert("Account created!");
})
.catch((error) => {
alert(error.message);
});

}
function login(event) {
  event.preventDefault();
}